#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "decode.h"
#include "types.h"

OperationType check_operation_type(char *argv[])
{
    if(strcmp(argv[1], "-e")== 0)
	return e_encode;
    else if(strcmp(argv[1],"-d") == 0 )
	return e_decode;
    else
	return e_unsupported;
}
int main(int argc, char *argv[])
{
    EncodeInfo encInfo;
    DecodeInfo decInfo;
    uint img_size;
    // Test open_files
    if(argc < 3)
    {
	printf("ERROR: too few arguments\n");
	return 1;
    }
    int res = check_operation_type(argv);

    if(res == e_encode)
    {
	if(read_and_validate_encode_args(argv, &encInfo) == e_success)
	{
	    printf("INFO: Opening required files\n" );
	    if (open_files(&encInfo) == e_failure)
	    {
		printf("ERROR: %s function failed\n", "open_files" );
		return 1;
	    }
	    else
	    {
		printf("INFO: Done\n" );
		printf("INFO: ## Encoding Procedure Started ##\n");
		do_encoding(&encInfo);
	    }
	}
	else
	{
	    printf("ERROR: read and validate\n");
	    return 1;
	}
    }
    else if(res == e_decode)
    {
	if(read_and_validate_decode_args(argv, &decInfo) == e_success)
	{
	    printf("INFO: ## Decoding Procedure Started ##\n");
	    printf("INFO: Opening required files \n");
	    if(open_files_for_decoding(&decInfo)==e_failure)
	    {
		printf("ERROR: %s function failed\n", "open_files" );
		return 1;
	    }
	    else
	    {
		printf("INFO: Done\n" );

		if(do_decoding(&decInfo) == e_success)
		printf("INFO: ## Decoding Done Successfully ##\n");
	    }
	}
	else
	{
	    printf("ERROR: read and validate\n");
	    return 1;
	}
    }
    else
    {
	printf("Invalid Option");
    }

/*Test get_image_size_for_bmp
  img_size = get_image_size_for_bmp(encInfo.fptr_src_image);
  printf("INFO: Image size = %u\n", img_size);
 */

/*int res = check_operation_type(argv);

  if(res == e_encode)
  {
  printf("INFO: ## Encoding Procedure Started ##\n");
  do_encoding(&encInfo);
  }
  else if(res == e_decode)
  {
  printf("Decoding : ");
  }
  else
  {
  printf("Invalid Option");
  }*/

return 0;
}
