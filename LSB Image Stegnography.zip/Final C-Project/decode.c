#include <stdio.h>
#include <string.h>
#include "decode.h"
#include "types.h"
#include "common.h"
Status read_and_validate_decode_args(char *argv[], DecodeInfo *decInfo)
{
    if(strstr(argv[2],".bmp") != NULL)
    {
	decInfo->src_image_fname = argv[2];
	if(argv[3] != NULL)
	{
	    strcpy(decInfo->output_image_fname,strtok(argv[3],"."));
	}
	else
	{
	    strcpy(decInfo->output_image_fname,"Decoded");
	}
    }
    else
    {
	printf("ERROR: Invalid File\n");
	return 1;
    }
    return e_success;

}

Status open_files_for_decoding(DecodeInfo *decInfo)
{
    decInfo->fptr_src_image = fopen(decInfo->src_image_fname,"r");
    if(decInfo->fptr_src_image == NULL)
    {
	perror("fopen");
	fprintf(stderr, "ERROR: Unable to open file %s\n",decInfo->src_image_fname);
	return e_failure;
    }
    else
    {
	printf("INFO: Opened %s\n",decInfo->src_image_fname);
	fseek(decInfo->fptr_src_image,54,SEEK_SET);
    }
    return e_success;
}

Status decode_magic_string(DecodeInfo *decInfo)
{
    char buffer[8],m_s[10];
    char magic_string[10];
    printf("What was Magic String ???");
    scanf("%s",magic_string);
    char bufferr[32];
    fread(bufferr,1,32,decInfo->fptr_src_image);
    int len; 
    len = decode_size_from_lsb(len, bufferr);
    int i;
    for( i=0;i<len;i++)
    {
	fread(buffer,1,8,decInfo->fptr_src_image);
	m_s[i] = decode_byte_from_lsb(m_s[i],buffer);
    }
    m_s[i] = '\0';
    //printf("%s\n",m_s);
    if(strcmp(m_s,magic_string) == 0)
	return e_success;
    else
	return e_failure;
}

Status decode_byte_from_lsb(char var, char *buffer)
{
    var = 0;
    for(int i=0;i<=7;i++)
    {
	var = (var | (buffer[i] & 1)<<(7-i));
    }
    return var;
}

Status decode_file_extn_size(DecodeInfo *decInfo)
{
    char buffer[32];
    fread(buffer,1,32,decInfo->fptr_src_image);
    decInfo->src_extn_size = decode_size_from_lsb(decInfo->src_extn_size, buffer);
    //printf("src_extn_size = %d\n", decInfo->src_extn_size);
    return e_success;
}

Status decode_size_from_lsb(int var, char *buffer)
{
    var = 0;
    for(int i=0;i<=31;i++)
    {
	var = (var | ((buffer[i] & 1)<<(31-i)));
    }
   // printf("var = %d\n", var);
    return var;
}

Status decode_file_extn(DecodeInfo *decInfo)
{
   
    //printf("extn size = %d\n",decInfo->src_extn_size);
    char src_extn[decInfo->src_extn_size+1];
    char buffer[8];
    int len = decInfo->src_extn_size,i;
    for( i=0;i<len;i++)
    {
	fread(buffer,1,8,decInfo->fptr_src_image);
	src_extn[i] = decode_byte_from_lsb(src_extn[i], buffer);
    }
    src_extn[i] = '\0';
    //printf("%s\n",src_extn);
    
    strcat(decInfo->output_image_fname,src_extn);
    decInfo->fptr_output_image = fopen(decInfo->output_image_fname,"w");
    //printf("%s\n",decInfo->output_image_fname);

    return e_success;
}


Status decode_file_size(DecodeInfo *decInfo)
{
    char buffer[32];
    fread(buffer,1,32,decInfo->fptr_src_image);
    decInfo->src_file_size = decode_size_from_lsb(decInfo->src_file_size, buffer);
    return e_success;
}

Status decode_file_data(DecodeInfo *decInfo)
{
    char buffer[8],var;
    int len = decInfo->src_file_size;
    //printf("len = %d\n", len);
    for(int i=0;i<len;i++)
    {
	fread(buffer,1,8,decInfo->fptr_src_image);
	var = decode_byte_from_lsb(var,buffer);
	fwrite(&var,1,1,decInfo->fptr_output_image);
    }
    return e_success;
}



Status do_decoding(DecodeInfo *decInfo)
{
	printf("INFO: Decoding Magic String Signature\n");

	if(decode_magic_string(decInfo)==e_success)
	{
	    printf("INFO: Done\n");
	    printf("INFO: Decoding Output File Extenstion size\n");
	    if(decode_file_extn_size(decInfo) == e_success)
	    {
		printf("INFO: Done\n");
		if(decode_file_extn(decInfo) == e_success)
		{
		    if(strcmp(decInfo->output_image_fname,"decoded.txt")==0)
			printf("INFO: Output File not mentioned. Creating decoded.txt as default\nINFO: Opened decoded.txt\n");
		    else
			printf("INFO: Opened %s\n",decInfo->output_image_fname);
		    printf("INFO: Done. Opened all required files\n");
		    printf("INFO: Decoding  File Size\n");
		    if(decode_file_size(decInfo) == e_success)
		    {
			printf("INFO: Done\nINFO: Decoding  File Data\n");
			if(decode_file_data(decInfo) == e_success)
			{
			    printf("INFO: Done\n");
			    return e_success;
			}
			else
			{
			    printf("ERROR: Decoding File data\n");
			}
		    }
		    else
		    {
			printf("ERROR: Decoding File size\n");
		    }
		}
	    else
	    {
		printf("ERROR: Decoding File extn\n");
	    }
	}
	else
	{
	    printf("ERROR: Decoding File extn size\n");
	}
    }
    else
    {
	printf("ERROR: Decoding Magic String\n");
    }
}




