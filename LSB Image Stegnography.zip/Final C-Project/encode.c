#include <stdio.h>
#include <string.h>
#include "encode.h"
#include "types.h"
#include "common.h"

/* Function Definitions */

/* Get image size
 * Input: Image file ptr
 * Output: width * height * bytes per pixel (3 in our case)
 * Description: In BMP Image, width is stored in offset 18,
 * and height after that. size is 4 bytes
 */
//
uint get_image_size_for_bmp(FILE *fptr_image)
{
    uint width, height;
    // Seek to 18th byte
    fseek(fptr_image, 18, SEEK_SET);

    // Read the width (an int)
    fread(&width, sizeof(int), 1, fptr_image);
    //printf("width = %u\n", width);

    // Read the height (an int)
    fread(&height, sizeof(int), 1, fptr_image);
    // printf("height = %u\n", height);

    // Return image capacity
    return width * height * 3;
}

/* 
 * Get File pointers for i/p and o/p files
 * Inputs: Src Image file, Secret file and
 * Stego Image file
 * Output: FILE pointer for above files
 * Return Value: e_success or e_failure, on file errors
 */
Status open_files(EncodeInfo *encInfo)
{
    // Src Image file
    encInfo->fptr_src_image = fopen(encInfo->src_image_fname, "r");
    // Do Error handling
    if (encInfo->fptr_src_image == NULL)
    {
	perror("fopen");
	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->src_image_fname);

	return e_failure;
    }
    else
	printf("INFO: Opened SkeletonCode/beautiful.bmp\n");

    // Secret file
    encInfo->fptr_secret = fopen(encInfo->secret_fname, "r");
    // Do Error handling
    if (encInfo->fptr_secret == NULL)
    {
	perror("fopen");
	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->secret_fname);

	return e_failure;
    }
    else
	printf("INFO: Opened secret.txt\n");

    // Stego Image file
    encInfo->fptr_stego_image = fopen(encInfo->stego_image_fname, "w");
    // Do Error handling
    if (encInfo->fptr_stego_image == NULL)
    {
	perror("fopen");
	fprintf(stderr, "ERROR: Unable to open file %s\n", encInfo->stego_image_fname);

	return e_failure;
    }
    else
	printf("INFO: Opened %s\n",encInfo->stego_image_fname);

    // No failure return e_success
    return e_success;
}
//
Status check_capacity(EncodeInfo *encInfo)
{
    encInfo->image_capacity = get_image_size_for_bmp(encInfo->fptr_src_image);
    encInfo->size_secret_file = get_file_size(encInfo->fptr_secret);

    if(((strlen(MAGIC_STRING) * 8) + 32 + (strlen(encInfo->extn_secret_file) * 8) + 32 + (encInfo->size_secret_file * 8)) 
	    < encInfo->image_capacity)
	return e_success;
    else
	return e_failure;
}
//
uint get_file_size(FILE *file)
{
    long int size;

    fseek(file, 0, SEEK_END);
    size = ftell(file);
    fseek(file, 0, SEEK_SET);

    return size;

}
//
Status copy_bmp_header(FILE *src_fptr, FILE *dest_fptr)
{
    rewind(src_fptr);
    char buffer[54];
    fread(buffer, 1, 54, src_fptr);
    fwrite(buffer, 1, 54, dest_fptr);
    return e_success;
}
Status encode_size_to_lsb(int size, char *buffer)
{
    // printf("size = %d\n", size);
    for(int i=0;i <= 31;i++)
    {
	buffer[i] = (buffer[i] & (~1)) | ((size & (1 << (31-i)))>>(31-i));
    }
    return e_success;
}
//
Status encode_magic_string(const char *m_s, EncodeInfo *encInfo)
{
    char buffer[8];
    int len;
    len = strlen(m_s);
    char bufferr[32];
    fread(bufferr, 1, 32, encInfo->fptr_src_image);
    encode_size_to_lsb(len, bufferr);
    fwrite(bufferr, 1, 32, encInfo->fptr_stego_image);
    for(int i=0;i<len;i++)
    {
	fread(buffer, 1, 8, encInfo->fptr_src_image);
	encode_byte_to_lsb(m_s[i], buffer);
	fwrite(buffer, 1, 8, encInfo->fptr_stego_image);
    }
    return e_success;
}
//
Status encode_byte_to_lsb(char data, char *buffer)
{
    for(int i=0;i <= 7;i++)
    {
	buffer[i] = (buffer[i] & 0xfe) | (((unsigned)data>>(7-i)) & 1);
    }
    return e_success;
}

//


Status read_and_validate_encode_args(char *argv[],EncodeInfo *encInfo)
{
    encInfo->src_image_fname = argv[2];
    if(strstr(encInfo->src_image_fname, ".bmp") == NULL){
	printf("Input file is not a .bmp file\n");
	return e_failure;
    }
    encInfo->secret_fname = argv[3];
    if(strstr(encInfo->secret_fname, ".txt") == NULL){
	printf("Secret file is not a .txt file\n");
	return e_failure;
    }
    strcpy(encInfo->extn_secret_file, strstr(argv[3],"."));
    if(argv[4] != NULL){
	encInfo->stego_image_fname = argv[4];
	if(strstr(encInfo->stego_image_fname, ".bmp") == NULL){
	    printf("Ouput file is not a .bmp file\n");
	    return e_failure;
	}
    }
    else
	encInfo->stego_image_fname = "stego.bmp";

    return e_success;
}

//
Status encode_secret_file_extn_size(long extn_size, EncodeInfo *encInfo)
{
    char buffer[32];
    fread(buffer, 1, 32, encInfo->fptr_src_image);
    encode_size_to_lsb(extn_size, buffer);
    fwrite(buffer, 1, 32, encInfo->fptr_stego_image);
    return e_success;


}
//
Status encode_secret_file_extn(const char *file_extn, EncodeInfo *encInfo)
{
    char buffer[8];
    int len = strlen(file_extn); 
    for(int i=0;i<len;i++)
    {
	fread(buffer, 1, 8, encInfo->fptr_src_image);
	encode_byte_to_lsb(file_extn[i], buffer);
	fwrite(buffer, 1, 8, encInfo->fptr_stego_image);
    }
    return e_success;
}
//
Status encode_secret_file_size(long file_size, EncodeInfo *encInfo)
{
    char buffer[32];

    fread(buffer, 1, 32, encInfo->fptr_src_image);
    encode_size_to_lsb(file_size, buffer);
    fwrite(buffer, 1, 32, encInfo->fptr_stego_image);

    return e_success;
}
//
Status encode_secret_file_data(EncodeInfo *encInfo)
{
    //printf("size_file = %d\n", encInfo->size_secret_file);
    char buffer[8], temp[encInfo->size_secret_file];
    fread(temp, 1, encInfo->size_secret_file, encInfo->fptr_secret);
    // int len = strlen(temp);
    // printf("len = %d\n", len);
    for(int i=0;i<encInfo->size_secret_file;i++)
    {
	fread(buffer, 1, 8, encInfo->fptr_src_image);
	//	printf("temp[i] = %c\n", temp[i]);
	encode_byte_to_lsb(temp[i], buffer);
	fwrite(buffer, 1, 8, encInfo->fptr_stego_image);
    }
    return e_success;
}

Status encode_data_to_image(char *data, int size, FILE *fptr_src_img, FILE *fptr_stego_img)
{
    char buffer[8];
    //int len = strlen(data);
    for(int i=0;i<size;i++)
    {
	fread(buffer, 1, 8, fptr_src_img);
	encode_byte_to_lsb(data[i], buffer);
	fwrite(buffer, 1, 8, fptr_stego_img);
    }
    return e_success;

}
//
Status copy_remaining_img_data(FILE *fptr_src, FILE *fptr_dest)
{
    char buffer[1024];
    size_t bytes_read;
    while ((bytes_read = fread(buffer, 1, sizeof(buffer), fptr_src)) > 0) 
    {
	fwrite(buffer, 1, bytes_read, fptr_dest);
    }
    return e_success;
}
//
Status do_encoding(EncodeInfo *encInfo)
{
    printf("INFO: Checking for secret.txt size\n");
    if(get_file_size(encInfo->fptr_secret) != 0)
    {
	printf("INFO: Done. Not Empty\n");
	printf("INFO: Checking for SkeletonCode/beautiful.bmp capacity to handle secret.txt\n");
	if(check_capacity(encInfo) == e_success)
	{
	    printf("INFO: Done. Found OK\n");
	    if(strcmp(encInfo->stego_image_fname,"stego.bmp")==0)
	    {
		printf("INFO: Output file not mentioned. Creating stego.bmp as default\n");
	    }
	    printf("INFO: Copying Image Header\n");
	    if(copy_bmp_header(encInfo->fptr_src_image, encInfo->fptr_stego_image) == e_success)
	    {
		printf("INFO: Done\n");
		char m_s[10];
		printf("Enter Magic String : ");
		scanf("%s",m_s);
		printf("INFO: Encoding Magic String Signature\n");
		if(encode_magic_string(m_s, encInfo) == e_success)
		{
		    printf("INFO: Done\n");
		    printf("INFO: Encoding secret.txt File Extenstion size\n");
		    if(encode_secret_file_extn_size(strlen(encInfo->extn_secret_file), encInfo) == e_success)
		    {
			printf("INFO: Done\n");
			printf("INFO: Encoding secret.txt File Extenstion \n");
			if(encode_secret_file_extn(encInfo->extn_secret_file, encInfo) == e_success)
			{
			    printf("INFO: Done\n");
			    printf("INFO: Encoding secret.txt File Size\n");
			    if(encode_secret_file_size(encInfo->size_secret_file, encInfo) == e_success)
			    {
				printf("INFO: Done\n");
				printf("INFO: Encoding secret.txt File Data\n");
				if(encode_secret_file_data(encInfo) == e_success)
				{
				    printf("INFO: Done\n");
				    printf("INFO: Copying Left Over Data\n");
				    if(copy_remaining_img_data(encInfo->fptr_src_image,encInfo->fptr_stego_image)==e_success)
				    {
					printf("INFO: Done\n");
					printf("INFO: ## Encoding Done Successfully\n");
				    }
				    else
				    {
					printf("ERROR: Copying remaining data\n");
					return 1;
				    }
				}
				else
				{
				    printf("ERROR: Encoding secret file Data\n");
				    return 1;
				}
			    }
			    else
			    {
				printf("ERROR: Encoding secret file size\n");
				return 1;
			    }

			}
			else
			{
			    printf("ERROR: Encoding secret file extenstion\n");
			    return 1;
			}
		    }
		    else
		    {
			printf("ERROR: Encoding secret file extenstion size\n");
			return 1;
		    }

		}
		else
		{
		    printf("ERROR: Encoding magic string\n");
		    return 1;
		}
	    }
	    else
	    {
		printf("ERROR: copy header\n");
		return 1;
	    }
	}
	else
	{
	    printf("ERROR: Check capacity\n");
	    return 1;
	}
    }
    else
    {
	printf("ERROR: Secret file is Empty\n");
	return 1;
    }
}










